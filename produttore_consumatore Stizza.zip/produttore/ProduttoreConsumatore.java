public class ProduttoreConsumatore {
    public static void main(String[] args) {
        Buffer buffer = new Buffer();
        
        Produttore prun = new Produttore(buffer, 0);
        Thread tpr = new Thread(prun);

        Consumatore crun = new Consumatore( buffer, 1);
        Thread tcn = new Thread(crun);
        
        tpr.start();
        tcn.start();
    }
}
