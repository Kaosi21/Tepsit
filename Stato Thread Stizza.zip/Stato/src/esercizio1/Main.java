package esercizio1;

import java.util.Random;
import java.util.Scanner;

//serve per la gestione degli input e della creazione di threads
public class Main {
    public static void main(String[] args) throws InterruptedException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Inserisci il numero di thread (T): ");
        int T = scanner.nextInt();
        System.out.print("Inserisci il valore massimo (N): ");
        int N = scanner.nextInt();
        scanner.close();

        Random random = new Random();
        ContatoreThread[] threads = new ContatoreThread[T];

        // Crea e avvia i thread
        for (int i = 0; i < T; i++) {
            int X = random.nextInt(N + 1);  // Genera un valore X casuale tra 0 e N
            threads[i] = new ContatoreThread(i, X);
            threads[i].start();
        }

        // Inizia a monitorare lo stato dei thread
        ThreadMonitor monitor = new ThreadMonitor(threads);
        monitor.monitor();
    }
}