package esercizio1;

//serve per il monitoraggio e la stampa dello stato dei threads
public class ThreadMonitor {
    private ContatoreThread[] threads;

    //costruttore
    public ThreadMonitor(ContatoreThread[] threads) {
        this.threads = threads;
    }

    public void monitor() throws InterruptedException {
        boolean tuttiCompletati = false;

        while (!tuttiCompletati) {
            tuttiCompletati = true;  // Assumi che tutti i thread siano completati finché non si trova uno attivo
            Thread.sleep(1000);  // Aspetta 1 secondo prima di stampare lo stato

            System.out.println("Stato dei Thread:");
            for (int i = 0; i < threads.length; i++) {
                if (threads[i].isAlive()) {
                    System.out.println("Thread " + i + " sta contando: " + threads[i].getValoreCorrente());
                    tuttiCompletati = false;  // Almeno un thread è ancora attivo
                } else {
                    System.out.println("Thread " + i + ": COMPLETATO");
                }
            }
            System.out.println();
        }

        // Stampa messaggio finale
        System.out.println("TUTTI I THREAD COMPLETATI");
    }
}