package esercizio1;

//si occupa del conteggio fino al valore di x dormendo 120ms tra ogni incremento
public class ContatoreThread extends Thread {
    private int id;
    private int X;
    private int valoreCorrente = 0;
    private boolean completato = false;
    
    //costruttore
    public ContatoreThread(int id, int X) {
        this.id = id;
        this.X = X;
    }

    public int getValoreCorrente() {
        return valoreCorrente;
    }

    public boolean isCompletato() {
        return completato;
    }

    @Override
    public void run() {
        try {
            for (valoreCorrente = 0; valoreCorrente <= X; valoreCorrente++) {
                Thread.sleep(120);  // Aspetta 120ms prima di continuare
            }
            completato = true;  // Segna il thread come completato
        } catch (InterruptedException e) { //in caso di eccezione viene messa nello stack
            e.printStackTrace();
        }
    }
}