/**
 * 
 */
/**
 * 
 */
module Stato {
}